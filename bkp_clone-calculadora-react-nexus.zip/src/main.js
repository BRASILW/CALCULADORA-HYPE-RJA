(this["webpackJsonpportfolio-guilherme-bafica"] =
  this["webpackJsonpportfolio-guilherme-bafica"] || []).push([
  [0],
  {
    30: function (e, t, n) {
      e.exports = n.p + "static/media/logoBackground.f9525ff2.png";
    },
    31: function (e, t, n) {
      e.exports = n.p + "static/media/newCalculator.0c3eca26.png";
    },
    34: function (e, t, n) {
      e.exports = n(47);
    },
    46: function (e, t, n) {},
    47: function (e, t, n) {
      "use strict";
      n.r(t);
      var a,
        i = n(1),
        r = n.n(i),
        o = n(11),
        c = n.n(o),
        l = n(2),
        d = n(14),
        m = (n(39), n(3)),
        s = {
          maxWidthContent: { large: "1100px" },
          background: "#F9FAFB",
          light: {
            0: "#FFF",
            1: "#EDF4FA",
            2: "#EBEBEB",
            3: "#f5f5f5",
            4: "#EAEDF0",
          },
          dark: {
            0: "#999797",
            1: "#4D4C4C",
            2: "#1A1919",
            3: "#7E7E81",
            4: "#BFBFC0",
            5: "#A8A5A0",
            6: "#C9D0D8",
            7: "#4C4C4C",
          },
          primary: { 0: "#8EB7AA", 1: "#C7DBD4", 2: "#5F9584", 3: "#518071" },
          secondary: { 0: "#CCD500", 1: "#F9FF6A", 2: "#666B00" },
          success: "#55BE6E",
          warning: "#FF8F39",
          danger: "#E8505B",
          fonts: {
            orelega: "'Orelega One', one",
            openSans: "'Open Sans', sans-serif",
          },
        },
        f = {
          primary: { redOne: "#f11c22", redTwo: "#e50027" },
          gray: {
            black: "#000000",
            white: "#FFFFFF",
            blackOne: "0c0c0c",
            grayOne: "#eef3f7",
            grayTwo: "#c9ced2",
            grayBackground: "#2f2f2f",
          },
          support: {
            red: "#fe0000",
            redLight: "#fe000066",
            green: "#05be05",
            greenLight: "#05be0566",
          },
        },
        u = Object(l.b)(
          a ||
            (a = Object(m.a)([
              "\n  * {\n    margin: 0;\n    padding: 0;\n    outline: 0;\n    box-sizing: border-box;\n    text-decoration: none;\n  }\n\n  a {\n    text-decoration: none; \n    text-decoration-line: none !important;\n  }\n\n  button {\n    text-decoration: none;  \n  }\n\n  body { \n    font-family: ",
              ";\n    background: ",
              ";\n    font-size: 1.125rem;\n    text-decoration: none; \n  }\n\n  *::selection {\n    background: ",
              ";\n    color: ",
              ";\n  }\n\n  html::-webkit-scrollbar {\n    /* width: 0.5rem; */\n    width: 0.3rem;\n  }\n\n  html::-webkit-scrollbar-track {\n    background: ",
              ";\n  }\n\n  html::-webkit-scrollbar-thumb {\n    background: ",
              ";\n  }\n",
            ])),
          s.fonts.openSans,
          s.background,
          f.primary.redTwo,
          f.gray.white,
          f.gray.black,
          f.primary.redTwo
        ),
        p = n(21),
        b = n(4);
      var g,
        x,
        h,
        y,
        v,
        w,
        k,
        E,
        A,
        T,
        O,
        j,
        F,
        I,
        C,
        z,
        S,
        D,
        B,
        P,
        R,
        q,
        L,
        N,
        M,
        V,
        U,
        Q,
        H,
        G,
        J,
        X,
        K,
        W,
        $,
        _,
        Y,
        Z,
        ee,
        te,
        ne,
        ae,
        ie,
        re,
        oe,
        ce,
        le = Object(b.f)(function (e) {
          var t = e.history;
          return (
            Object(i.useEffect)(function () {
              var e = t.listen(function () {
                window.scrollTo(0, 0);
              });
              return function () {
                e();
              };
            }, []),
            null
          );
        }),
        de = n(18),
        me = n(19),
        se = n(10),
        fe = n(24),
        ue = n(32),
        pe = n(33),
        be = [
          "id",
          "text",
          "color",
          "size",
          "align",
          "marginBottom",
          "marginTop",
          "marginLeft",
          "marginRight",
          "margin",
          "weight",
          "textDecoration",
          "ellipsis",
        ],
        ge = l.d.p(
          g ||
            (g = Object(m.a)([
              "\n  color: ",
              ";\n  font-size: ",
              "rem;\n  text-align: ",
              ";\n  margin: ",
              "rem;\n  line-height: ",
              "rem;\n  margin-bottom: ",
              "rem;\n  margin-top: ",
              "rem;\n  margin-left: ",
              "rem;\n  margin-right: ",
              "rem;\n  font-weight: ",
              ";\n  text-decoration-line: ",
              ";\n  font-family: ",
              ";\n  letter-spacing: ",
              "rem;\n  z-index: ",
              ";\n  position: relative;\n\n  ",
              "\n",
            ])),
          function (e) {
            return e.color || f.gray.black;
          },
          function (e) {
            var t = e.size;
            return (void 0 === t ? 16 : t) / 10;
          },
          function (e) {
            var t = e.align;
            return void 0 === t ? "center" : t;
          },
          function (e) {
            var t = e.margin;
            return (void 0 === t ? 0 : t) / 10;
          },
          function (e) {
            var t = e.size;
            return (1.3 * (void 0 === t ? 16 : t)) / 10;
          },
          function (e) {
            var t = e.marginBottom;
            return (void 0 === t ? 0 : t) / 10;
          },
          function (e) {
            var t = e.marginTop;
            return (void 0 === t ? 0 : t) / 10;
          },
          function (e) {
            var t = e.marginLeft;
            return (void 0 === t ? 0 : t) / 10;
          },
          function (e) {
            var t = e.marginRight;
            return (void 0 === t ? 0 : t) / 10;
          },
          function (e) {
            var t = e.weight;
            return void 0 === t ? "400" : t;
          },
          function (e) {
            return e.textDecoration || "none";
          },
          function (e) {
            return e.fontFamily || "Dosis";
          },
          function (e) {
            var t = e.letterSpacing;
            return (void 0 === t ? 1 : t) / 10;
          },
          function (e) {
            var t = e.zIndex;
            return void 0 === t ? 1 : t;
          },
          function (e) {
            return (
              e.ellipsis &&
              Object(l.c)(
                x ||
                  (x = Object(m.a)([
                    "\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    }\n  ",
                  ]))
              )
            );
          }
        ),
        xe = function (e) {
          var t = e.id,
            n = e.text,
            a = e.color,
            i = e.size,
            o = e.align,
            c = e.marginBottom,
            l = e.marginTop,
            d = e.marginLeft,
            m = e.marginRight,
            s = e.margin,
            f = e.weight,
            u = e.textDecoration,
            p = e.ellipsis,
            b = Object(pe.a)(e, be);
          return r.a.createElement(
            ge,
            Object.assign(
              {
                id: t,
                color: a,
                size: i,
                align: o,
                marginBottom: c,
                marginTop: l,
                marginLeft: d,
                marginRight: m,
                margin: s,
                weight: f,
                textDecoration: u,
                ellipsis: p,
              },
              b
            ),
            n
          );
        },
        he = l.d.div(
          h ||
            (h = Object(m.a)([
              "\n  margin: 0; \n  padding: 0;\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  font-family: 'Roboto';\n  cursor: pointer;\n",
            ]))
        ),
        ye = l.d.button(
          y ||
            (y = Object(m.a)([
              "\n  position: relative;\n  display: inline-block;\n  padding: 15px 30px;\n  color: ",
              ";\n  border: 1px solid ",
              ";\n  text-transform: uppercase;\n  letter-spacing: 4px;\n  text-decoration: none;\n  font-size: ",
              "rem;\n  overflow: hidden;\n  transition: all 0.2s ease-in-out;\n  font-weight: 500;\n  font-family: Montroc;\n  z-index: 3;\n\n  background: ",
              ";\n\n  box-shadow: ",
              ";\n  \n  &:hover {\n    color: ",
              ";\n    background: ",
              ";\n    box-shadow: 0 0 10px ",
              ", \n                0 0 40px ",
              ", \n                0 0 80px ",
              ";\n    transform: scale(1.02);\n  }\n",
            ])),
          f.gray.white,
          f.primary.redTwo,
          function (e) {
            var t = e.fontSize;
            return (void 0 === t ? 16 : t) / 10;
          },
          function (e) {
            var t = e.isActive;
            return "".concat(t ? f.primary.redOne : f.gray.black);
          },
          function (e) {
            return e.isActive
              ? "0 0 10px "
                  .concat(f.primary.redTwo, ", \n         0 0 40px ")
                  .concat(f.primary.redTwo, ", \n         0 0 80px ")
                  .concat(f.primary.redTwo, ";")
              : "none";
          },
          f.gray.white,
          f.primary.redOne,
          f.primary.redTwo,
          f.primary.redTwo,
          f.primary.redTwo
        ),
        ve = function (e) {
          var t = e.text,
            n = e.fontSize,
            a = e.isActive,
            i = e.onClick;
          return r.a.createElement(
            r.a.Fragment,
            null,
            r.a.createElement(
              he,
              null,
              r.a.createElement(ye, { fontSize: n, isActive: a, onClick: i }, t)
            )
          );
        },
        we = l.d.label(
          v ||
            (v = Object(m.a)([
              "\n  position: relative;\n  /* width: 160px; */\n  /* height: 80px; */\n  width: 80px;\n  height: 40px;\n  cursor: pointer;\n",
            ]))
        ),
        ke = l.d.input(
          w ||
            (w = Object(m.a)([
              "\n  position: relative;\n  z-index: 1;\n  appearance: none;\n\n  &:checked ~ span {\n    background-color: ",
              ";\n    /* box-shadow: 0 15px 25px ",
              "; */\n    box-shadow: 0 7px 12px ",
              ";\n  }\n\n  &:checked ~ span i {\n    /* left: 84px; */\n    left: 42px;\n\n    // Rosto \n    &::before {\n      background: ",
              ";\n      /* box-shadow: 31px 0 0 ",
              "; */\n      box-shadow: 15px 0 0 ",
              ";\n    }\n\n    &::after {\n      border-radius: 0;\n      background: ",
              ";\n      /* height: 15px; */\n      /* bottom: 12px; */\n      height: 7px;\n      bottom: 6px;\n      /* border-bottom-left-radius: 15px; */\n      /* border-bottom-right-radius: 15px; */\n      border-bottom-left-radius: 7px;\n      border-bottom-right-radius: 7px;\n    }\n    // Rosto \n  }\n",
            ])),
          f.support.green,
          f.support.greenLight,
          f.support.greenLight,
          f.support.green,
          f.support.green,
          f.support.green,
          f.support.green
        ),
        Ee = l.d.span(
          k ||
            (k = Object(m.a)([
              "\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background: ",
              ";\n  /* border-radius: 80px; */\n  border-radius: 40px;\n  transition: 0.5s;\n  /* box-shadow: 0 15px 25px ",
              "; */\n  box-shadow: 0 7px 12px ",
              ";\n",
            ])),
          f.support.red,
          f.support.redLight,
          f.support.redLight
        ),
        Ae = l.d.i(
          E ||
            (E = Object(m.a)([
              "\n  position: absolute;\n  /* top: 4px; */\n  /* left: 4px; */\n  top: 3px;\n  left: 3px;\n  /* width: 72px; */\n  /* height: 72px; */\n  width: 34px;\n  height: 34px;\n  background: ",
              ";\n  border-radius: 50%;\n  transition: 0.5s;\n\n  // Rosto \n  &::before {\n    content: '';\n    position: absolute;\n    /* top: 22px; */\n    /* left: 12px; */\n    top: 11px;\n    left: 6px;\n    /* width: 12px; */\n    /* height: 12px; */\n    width: 6px;\n    height: 6px;\n    background: ",
              ";\n    border-radius: 50%;\n    /* box-shadow: 31px 0 0 ",
              "; */\n    box-shadow: 15px 0 0 ",
              ";\n    transition: 0.5s;\n  }\n\n  &::after {\n    content: '';\n    position: absolute;\n    /* bottom: 15px; */\n    bottom: 7px;\n    /* left: calc(50% - 15px); */\n    left: calc(50% - 7px);\n    /* width: 30px; */\n    width: 15px;\n    /* height: 6px; */\n    height: 3px;\n    transition: 0.5s;\n    /* border-radius: 6px; */\n    border-radius: 3px;\n    background: ",
              ";\n  }\n  // Rosto \n",
            ])),
          f.gray.white,
          f.support.red,
          f.support.red,
          f.support.red,
          f.support.red
        ),
        Te = l.d.div(
          A ||
            (A = Object(m.a)([
              "\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n",
            ]))
        ),
        Oe = function (e) {
          var t = e.text,
            n = e.onClick,
            a = e.className;
          return r.a.createElement(
            r.a.Fragment,
            null,
            r.a.createElement(
              Te,
              null,
              r.a.createElement(
                we,
                { onClick: n },
                r.a.createElement(ke, { type: "checkbox", className: a }),
                r.a.createElement(Ee, null, r.a.createElement(Ae, null))
              ),
              r.a.createElement(xe, {
                text: t,
                align: "left",
                color: f.gray.white,
                size: 8,
                marginLeft: 8,
                weight: "500",
                fontFamily: "HighSpeed",
              })
            )
          );
        },
        je = [
          {
            article: "Art. 31",
            name: "Ass\xe9dio moral e f\xedsico (necessita provas)",
            time: 10,
            trafficTicket: 1e4,
            bail: 3e4,
            note: "",
            color: "#fff2cc",
          },
          {
            article: "Art. 32",
            name: "Usurpa\xe7\xe3o de poderes p\xfablicos",
            time: 20,
            trafficTicket: 2e4,
            bail: 6e4,
            note: "",
            color: "#fff2cc",
          },
          {
            article: "Art. 33",
            name: "M\xe1scara (fora de a\xe7\xe3o)",
            time: 10,
            trafficTicket: 1e4,
            bail: 3e4,
            note: "",
            color: "#fff2cc",
          },
          {
            article: "Art. 34",
            name: "Uso n\xe3o autorizado de equipamento da pol\xedcia",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#fff2cc",
          },
          {
            article: "Art. 35",
            name: "Apologia ao crime (elogia)",
            time: 15,
            trafficTicket: 15e3,
            bail: 45e3,
            note: "Autor",
            color: "#fff2cc",
          },
          {
            article: "Art. 36",
            name: "Falso testemunho",
            time: 15,
            trafficTicket: 15e3,
            bail: 45e3,
            note: "",
            color: "#fff2cc",
          },
          {
            article: "Art. 37",
            name: "Resist\xeancia a pris\xe3o",
            time: 15,
            trafficTicket: 15e3,
            bail: 45e3,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 38",
            name: "Omiss\xe3o de socorro (necessita de provas)",
            time: 5,
            trafficTicket: 5e3,
            bail: 15e3,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 39",
            name: "Dano a patrim\xf4nio (por unidade)",
            time: 5,
            trafficTicket: 5e3,
            bail: 15e3,
            note: "Por unidade",
            color: "#FFD966",
          },
          {
            article: "Art. 40",
            name: "Difama\xe7\xe3o (ofensa a honra da pessoa)",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "Publicamente",
            color: "#FFD966",
          },
          {
            article: "Art. 41",
            name: "Furto",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 42",
            name: "Obstru\xe7\xe3o de justi\xe7a",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 43",
            name: "Agress\xe3o corporal culposa (sem inten\xe7\xe3o)",
            time: 20,
            trafficTicket: 2e4,
            bail: 6e4,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 44",
            name: "Agress\xe3o corporal dolosa (com inten\xe7\xe3o)",
            time: 40,
            trafficTicket: 4e4,
            bail: 12e4,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 45",
            name: "inj\xfaria (xingamento/ofensa direta)",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 46",
            name: "Amea\xe7a (necessita de provas)",
            time: 35,
            trafficTicket: 35e3,
            bail: 105e3,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 47",
            name: "Incita\xe7\xe3o ao crime (incentivar algu\xe9m)",
            time: 20,
            trafficTicket: 2e4,
            bail: 6e4,
            note: "A terceiro",
            color: "#FFD966",
          },
          {
            article: "Art. 48",
            name: "Fuga (desobedi\xeancia a ordem de parada)",
            time: 10,
            trafficTicket: 1e4,
            bail: 3e4,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 49",
            name: "Roubo a caixa banc\xe1rio ou registradora",
            time: 20,
            trafficTicket: 2e4,
            bail: 6e4,
            note: "",
            color: "#FFD966",
          },
          {
            article: "Art. 50",
            name: "Desacato (Sem Fian\xe7a)",
            time: 15,
            trafficTicket: 15e3,
            bail: 0,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 51",
            name: "Extorna\xe7\xe3o (necessita de provas)",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 52",
            name: "Falsidade ideol\xf3gica (omitir a verdade, necessita de provas)",
            time: 10,
            trafficTicket: 1e4,
            bail: 3e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 53",
            name: "Cal\xfania (acusa\xe7\xe3o false de crime, necessita de provas)",
            time: 10,
            trafficTicket: 1e4,
            bail: 3e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 54",
            name: "Suborno (necessita de provas)",
            time: 10,
            trafficTicket: 1e4,
            bail: 2e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 55",
            name: "Atendado ao pudor (assediar algu\xe9m)",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 56",
            name: "Polui\xe7\xe3o sonora",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "SF",
            color: "#F1C232",
          },
          {
            article: "Art. 57",
            name: "Roubo/furto de carro oficial da cidade",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 58",
            name: "Roubo/furto de ve\xedculos",
            time: 20,
            trafficTicket: 2e4,
            bail: 6e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 59",
            name: "Abuso de autoridade",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 60",
            name: "Homic\xeddio doloso (com inten\xe7\xe3o)",
            time: 85,
            trafficTicket: 85e3,
            bail: 0,
            note: "SF",
            color: "#BF9000",
          },
          {
            article: "Art. 61",
            name: "Homic\xeddio culposo (sem inten\xe7\xe3o)",
            time: 50,
            trafficTicket: 5e4,
            bail: 0,
            note: "SF",
            color: "#BF9000",
          },
          {
            article: "Art. 62",
            name: "Tentativa de homic\xeddio",
            time: 45,
            trafficTicket: 45e3,
            bail: 0,
            note: "SF",
            color: "#BF9000",
          },
          {
            article: "Art. 63",
            name: "Latroc\xednio (roubou e matou)",
            time: 15,
            trafficTicket: 15e3,
            bail: 45e3,
            note: "SF",
            color: "#BF9000",
          },
          {
            article: "Art. 64",
            name: "Sequestro",
            time: 25,
            trafficTicket: 25e3,
            bail: 0,
            note: "SF",
            color: "#BF9000",
          },
          {
            article: "Art. 65",
            name: "Desobedi\xeancia",
            time: 15,
            trafficTicket: 15e3,
            bail: 45e3,
            note: "",
            color: "#F1C232",
          },
          {
            article: "Art. 71.1",
            name: "Porte pistola sem registro",
            time: 80,
            trafficTicket: 8e4,
            bail: 24e4,
            note: "",
            color: "#E06666",
          },
          {
            article: "Art. 71.2",
            name: "Porte de submetralhadora sem registro",
            time: 120,
            trafficTicket: 12e4,
            bail: 36e4,
            note: "",
            color: "#E06666",
          },
          {
            article: "Art. 71.3",
            name: "Porte de fuzil sem registro",
            time: 150,
            trafficTicket: 15e4,
            bail: 45e4,
            note: "",
            color: "#E06666",
          },
          {
            article: "Art. 73",
            name: "Mal uso de arma de fogo com registro (cassa\xe7\xe3o do porte)",
            time: 30,
            trafficTicket: 3e4,
            bail: 9e4,
            note: "",
            color: "#E06666",
          },
        ],
        Fe = [
          {
            article: "Art. 45 I",
            name: "Dirigir sem aten\xe7\xe3o ou sem cuidado a seguran\xe7a",
            time: 0,
            trafficTicket: 3e3,
            bail: 0,
            note: "",
            color: "#f2dcfb",
          },
          {
            article: "Art. 45 II",
            name: "Estacionar em acostamentos",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#f2dcfb",
          },
          {
            article: "Art. 45 III",
            name: "Luz alta em vias com ilumina\xe7\xe3o",
            time: 0,
            trafficTicket: 3e3,
            bail: 0,
            note: "",
            color: "#f2dcfb",
          },
          {
            article: "Art. 45 IV",
            name: "Usar buzina prolongada e sucessivamente",
            time: 0,
            trafficTicket: 3e3,
            bail: 0,
            note: "",
            color: "#f2dcfb",
          },
          {
            article: "Art. 46 I",
            name: "Atirar do veiculo objetos ou subst\xe2ncias",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 46 II",
            name: "Ficar sem combust\xedvel na via publica",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 46 III",
            name: "Transitar ao lado de outro ve\xedculo",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 46 IV",
            name: "Transitar em velocidade inferior a metade da m\xe1xima",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 46 V",
            name: "Usar alarme ou aparelho que produz som perturbante",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 46 VI",
            name: "Estacionar o veiculo em local proibido",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 46 VII",
            name: "Exceder o limite de velocidade em at\xe9 30% da velocidade permitida",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 46 VIII",
            name: "Ultrapassar o sinal vermelho",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#e6b8b7",
          },
          {
            article: "Art. 47 I",
            name: "Deixar de usar o cinto de seguran\xe7a",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 II",
            name: "Deixar de prestar socorro a v\xedtima de acidente",
            time: 0,
            trafficTicket: 7e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 III",
            name: "Fazer ou deixar que se fa\xe7a reparo no ve\xedculo em vias r\xe1pidas",
            time: 0,
            trafficTicket: 6e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 IV",
            name: "Transitar na contram\xe3o em via de duplo sentido",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 V",
            name: "Transitar em marcha r\xe9, salvo para manobras",
            time: 0,
            trafficTicket: 8e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 VI",
            name: "Desobedecer ordens emanadas da autoridade competente",
            time: 0,
            trafficTicket: 8e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 VII",
            name: "Deixar de reduzir a velocidade onde o tr\xe2nsito esteja controlado",
            time: 0,
            trafficTicket: 6e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 VIII",
            name: "Conduzir o veiculo em m\xe1 estado de conserva\xe7\xe3o",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 IX",
            name: "Evadir-se para n\xe3o pagar ped\xe1gio, quando houver",
            time: 0,
            trafficTicket: 6e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 X",
            name: "Deixar o motociclista de usar o capacete",
            time: 0,
            trafficTicket: 5e3,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 47 XI",
            name: "Exceder o limite de velocidade em at\xe9 70% da velocidade permitida",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#da9694",
          },
          {
            article: "Art. 48 II",
            name: "Transitar pela contram\xe3o em via de sentido \xfanico",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#963634",
          },
          {
            article: "Art. 48 III",
            name: "Deixar de dar passagem a ve\xedculos de socorro",
            time: 0,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#963634",
          },
          {
            article: "Art. 48 IV",
            name: "Exceder o limite de velocidade acima de 70% da velocidade permitida",
            time: 0,
            trafficTicket: 15e3,
            bail: 0,
            note: "",
            color: "#963634",
          },
          {
            article: "Art. 86",
            name: "Praticar homic\xeddio culposo (VDM)",
            time: 30,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 86 1\xba I",
            name: "Praticar homic\xeddio culposo na faixa de pedestre (VDM)",
            time: 40,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 86 1\xba II",
            name: "Praticar homic\xeddio culposo e n\xe3o prestar socorro (VDM)",
            time: 50,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 86 1\xba III",
            name: "Praticar homic\xeddio culposo no exerc\xedcio de fun\xe7\xe3o ou atividade (VDM)",
            time: 60,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 87",
            name: "Praticar les\xe3o corporal culposa",
            time: 30,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 87 1\xba",
            name: "Aumenta-se a pena em qualquer situa\xe7\xe3o do homic\xeddio culposo",
            time: 50,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 86 2\xba",
            name: "Conduzir com capacidade psicomotora alterada (\xe1lcool ou drogas)",
            time: 40,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 86 3\xba",
            name: "Crime acima e o condutor alegar depend\xeancia de drogas ou \xe1lcool",
            time: 60,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 88",
            name: "Deixar de prestar socorro imediato a v\xedtima em caso de acidente",
            time: 40,
            trafficTicket: 0,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 89",
            name: "Afastar-se o condutor do ve\xedculo no acidente para n\xe3o ser responsabilizado",
            time: 30,
            trafficTicket: 15e3,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 90",
            name: "Conduzir sob influencia de \xe1lcool ou subst\xe2ncias an\xe1logas e expor outrem a danos",
            time: 40,
            trafficTicket: 2e4,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 91",
            name: "Participar de corrida, disputa ou competi\xe7\xe3o n\xe3o autorizada em via p\xfablica",
            time: 30,
            trafficTicket: 3e4,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 91 1\xba",
            name: "Crime acima e resultar les\xe3o corporal de outrem",
            time: 40,
            trafficTicket: 3e4,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 91 2\xba",
            name: "Crime acima e resultar morte de outre",
            time: 50,
            trafficTicket: 3e4,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 92",
            name: "Trafegar em velocidade incompat\xedvel perto de hospitais, pra\xe7a, DP, etc...",
            time: 20,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
          {
            article: "Art. 93",
            name: "Modificar o local do acidente para induzir ao erro a autoridade policial",
            time: 40,
            trafficTicket: 1e4,
            bail: 0,
            note: "",
            color: "#b1a0c7",
          },
        ],
        Ie = [
          {
            article: "Art. 67",
            name: "Contrabando de materiais restritos",
            time: 0.28,
            trafficTicket: 285.71,
            bail: 857.14,
            note: "A cada 35",
            color: "#E06666",
            minQuantity: 35,
          },
          {
            article: "Art. 68.1",
            name: "Maconha",
            time: 0.5,
            trafficTicket: 500,
            bail: 1500,
            note: "A cada 10",
            color: "#E06666",
            minQuantity: 10,
          },
          {
            article: "Art. 68.2",
            name: "Coca\xedna",
            time: 0.5,
            trafficTicket: 500,
            bail: 1500,
            note: "A cada 10",
            color: "#E06666",
            minQuantity: 10,
          },
          {
            article: "Art. 68.3",
            name: "Metanfetamina",
            time: 0.5,
            trafficTicket: 500,
            bail: 1500,
            note: "A cada 10",
            color: "#E06666",
            minQuantity: 10,
          },
          {
            article: "Art. 68.4",
            name: "LSD",
            time: 0.5,
            trafficTicket: 500,
            bail: 1500,
            note: "A cada 10",
            color: "#E06666",
            minQuantity: 10,
          },
          {
            article: "Art. 69",
            name: "Dinheiro sujo",
            time: 5e-4,
            trafficTicket: 0.5,
            bail: 1.5,
            note: "A cada 10000",
            color: "#E06666",
            minQuantity: 1e4,
          },
          {
            article: "Art. 70",
            name: "Lockpick / Algema / Capuz / C4 / Pendrive / Keycard / Colete",
            time: 15,
            trafficTicket: 15e3,
            bail: 45e3,
            note: "A cada 1",
            color: "#E06666",
            minQuantity: 1,
          },
          {
            article: "Art. 72",
            name: "Porte de muni\xe7\xe3o sem registro",
            time: 1,
            trafficTicket: 1e3,
            bail: 3e3,
            note: "A cada 35",
            color: "#E06666",
            minQuantity: 35,
          },
        ],
        Ce = n(30),
        ze = n.n(Ce),
        Se = n(31),
        De = n.n(Se),
        Be = Object(l.e)(
          T ||
            (T = Object(m.a)([
              "\n  0%, 100% { \n    transform: scale(1);\n  }\n\n  50% { \n    transform: scale(1.1);\n  }\n",
            ]))
        ),
        Pe = l.d.div(
          O ||
            (O = Object(m.a)([
              "\n  background: ",
              ";\n  min-height: 100vh;\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n",
            ])),
          f.primary.redTwo
        ),
        Re = l.d.div(
          j ||
            (j = Object(m.a)([
              "\n  width: 100%;\n  padding: 1rem 0;\n  background: ",
              ";\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: center;\n",
            ])),
          f.primary.redTwo
        ),
        qe = l.d.div(
          F ||
            (F = Object(m.a)([
              "\n  background: ",
              ";\n  min-height: 100vh;\n  width: 99%;\n  border-top-left-radius: 32px;\n  border-top-right-radius: 32px;\n  margin-top: -32px;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: flex-start;\n  padding: 2% 5%;\n\n  position: relative;\n  overflow: hidden;\n",
            ])),
          f.gray.black
        ),
        Le = l.d.div(
          I ||
            (I = Object(m.a)([
              "\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  align-items: flex-start;\n  justify-content: space-between;\n  position: relative;\n  z-index: 100;\n\n  @media screen and (max-width: 960px) {\n    flex-direction: column;\n    justify-content: flex-start;\n  }\n",
            ]))
        ),
        Ne = l.d.div(
          C ||
            (C = Object(m.a)([
              "\n  width: 42%;\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  margin-top: 4px;\n\n  @media screen and (max-width: 960px) {\n    width: 100%;\n    margin-top: 1rem;\n\n    > p {\n      font-size: 16px;\n    }\n  }\n",
            ]))
        ),
        Me = l.d.div(
          z ||
            (z = Object(m.a)([
              "\n  width: 58%;\n  padding-bottom: 32px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-end;\n\n  @media screen and (max-width: 960px) {\n    width: 100%;\n    margin-top: 2rem;\n\n    button {\n      font-size: 12px;\n      width: 100%;\n    }\n  }\n\n  @media screen and (max-width: 700px) {\n    flex-direction: column;\n    justify-content: flex-start;\n    margin-top: 3rem;\n  }\n",
            ]))
        ),
        Ve = l.d.div(
          S ||
            (S = Object(m.a)([
              "\n  height: 100%;\n  width: 8px;\n\n  @media screen and (max-width: 700px) {\n    height: 1rem;\n  }\n",
            ]))
        ),
        Ue = l.d.div(
          D ||
            (D = Object(m.a)([
              "\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  overflow: hidden;\n  display: flex;\n  align-items: flex-start;\n  justify-content: center;\n  z-index: 1;\n\n  @media screen and (max-width: 960px) {\n    top: 30%;\n  }\n\n  @media screen and (max-width: 700px) {\n    top: 40%;\n  }\n\n  @media screen and (max-width: 560px) {\n    top: 50%;\n  }\n\n  @media screen and (max-width: 400px) {\n    top: 55%;\n  }\n",
            ]))
        ),
        Qe = l.d.img(
          B ||
            (B = Object(m.a)([
              "\n  width: 50%;\n  -o-object-fit: cover;\n  object-fit: cover;\n  background: ",
              ";\n\n  @media screen and (max-width: 960px) {\n    width: 90%;\n  }\n",
            ])),
          f.gray.black
        ),
        He = l.d.div(
          P ||
            (P = Object(m.a)([
              "\n  width: 90%;\n  height: 100%;\n  background: #00000099;\n  position: absolute;\n",
            ]))
        ),
        Ge = l.d.div(
          R ||
            (R = Object(m.a)([
              "\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  justify-content: flex-start;\n",
            ]))
        ),
        Je = l.d.div(
          q ||
            (q = Object(m.a)([
              "\n  width: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-bottom: 2rem;\n  z-index: 10;\n",
            ]))
        ),
        Xe = l.d.div(
          L ||
            (L = Object(m.a)([
              "\n  width: 100%;\n  border-radius: 8px;\n  z-index: 3;\n  margin-bottom: 60px;\n  background: #00000099;\n  border: 4px solid ",
              ";\n  display: flex;\n  flex-direction: row;\n  padding: 16px 0;\n\n  @media screen and (max-width: 960px) {\n    flex-direction: column;\n    padding: 16px;\n  }\n",
            ])),
          f.primary.redTwo
        ),
        Ke = l.d.div(
          N ||
            (N = Object(m.a)([
              "\n  width: 33%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  padding: 16px;\n\n  @media screen and (max-width: 960px) {\n    width: 100%;\n    padding: 16px 32px;\n  }\n",
            ]))
        ),
        We = l.d.div(
          M ||
            (M = Object(m.a)([
              "\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n  width: 33%;\n  border-left: 4px solid ",
              ";\n  border-right: 4px solid ",
              ";\n  padding: 16px;\n\n  @media screen and (max-width: 960px) {\n    width: 100%;\n    padding: 16px 32px;\n\n    border-left: none;\n    border-right: none;\n    border-top: 4px solid ",
              ";\n    border-bottom: 4px solid ",
              ";\n  }\n",
            ])),
          f.primary.redTwo,
          f.primary.redTwo,
          f.primary.redTwo,
          f.primary.redTwo
        ),
        $e = l.d.div(
          V ||
            (V = Object(m.a)([
              "\n  padding: 16px;\n  width: 33%;\n  height: 100%;\n  display: flex;\n  flex-direction: column;\n\n  @media screen and (max-width: 960px) {\n    width: 100%;\n    padding: 16px 32px;\n  }\n",
            ]))
        ),
        _e = l.d.div(
          U ||
            (U = Object(m.a)([
              "\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n",
            ]))
        ),
        Ye = l.d.div(
          Q ||
            (Q = Object(m.a)([
              "\n  display: ",
              ";\n  flex-direction: column;\n  z-index: 2;\n  width: 100%;\n  padding-top: 16px;\n  margin-bottom: 100px;\n",
            ])),
          function (e) {
            return e.display ? "flex" : "none";
          }
        ),
        Ze = l.d.select(
          H ||
            (H = Object(m.a)([
              "\n  width: 100%;\n  height: 50px;\n  background-color: ",
              ";\n  border-color: ",
              ";\n  color: ",
              ";\n  border-radius: 4px;\n  border-width: 2px;\n  padding: 0 16px;\n  font-size: 16px;\n  font-weight: 700;\n  font-family: Roboto;\n\n  &+select {\n    margin-top: 8px;\n  }\n",
            ])),
          f.gray.grayBackground,
          f.primary.redTwo,
          f.gray.white
        ),
        et = l.d.option(G || (G = Object(m.a)([""]))),
        tt = l.d.div(
          J ||
            (J = Object(m.a)([
              "\n  background: ",
              ";\n  width: 99%;\n  padding: 0 10%;\n  padding-bottom: 2rem;\n  padding-top: 4rem;\n",
            ])),
          f.gray.black
        ),
        nt = l.d.div(
          X ||
            (X = Object(m.a)([
              "\n  padding: 1rem 0;\n  border-bottom: 1px solid ",
              ";\n  width: 100%;\n  display: flex;\n  justify-content: flex-end; \n\n  @media screen and (max-width: 560px) {\n    justify-content: center; \n  }\n",
            ])),
          f.primary.redTwo
        ),
        at = l.d.div(
          K ||
            (K = Object(m.a)([
              "\n  background: transparent;\n  border: none;\n  cursor: pointer;\n  transition: all 0.3s ease-in-out;\n\n  > h1 {\n    > span {\n      font-size: 7px;\n    }\n  }\n\n  &:hover {\n    transform: scale(1.1);\n\n    > h1 {\n      color: ",
              ";\n    }\n  }  \n",
            ])),
          f.primary.redTwo
        ),
        it = l.d.h1(
          W ||
            (W = Object(m.a)([
              "\n  color: ",
              ";\n  font-size: 10px;\n  font-family: 'HighSpeed';\n  transition: all 0.3s ease-in-out;\n  text-decoration: underline;\n",
            ])),
          f.gray.white
        ),
        rt = l.d.div(
          $ ||
            ($ = Object(m.a)([
              "\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  margin-top: 8px;\n  margin-bottom: 16px;\n",
            ]))
        ),
        ot = l.d.div(
          _ ||
            (_ = Object(m.a)([
              "\n  z-index: 10;\n  height: 60px;\n  width: 60px;\n  margin-left: -28px;\n  margin-top: -20px;\n  transform: rotate(45deg);\n",
            ]))
        ),
        ct = l.d.img(
          Y ||
            (Y = Object(m.a)([
              "\n  width: 100%;\n  -o-object-fit: cover;\n  object-fit: cover;\n",
            ]))
        ),
        lt = l.d.div(
          Z ||
            (Z = Object(m.a)([
              "\n  display: flex;\n  flex-direction: column;\n  z-index: 2;\n  width: 100%;\n  flex-direction: row;\n  align-items: center;\n  justify-content: space-between;\n\n  &+div {\n    margin-top: 8px;\n  }\n\n  @media screen and (max-width: 700px) {\n    flex-direction: column;\n    align-items: center;\n    justify-content: flex-start;\n  }\n",
            ]))
        ),
        dt = l.d.select(
          ee ||
            (ee = Object(m.a)([
              "\n  width: 60%;\n  height: 50px;\n  background-color: ",
              ";\n  border-color: ",
              ";\n  color: ",
              ";\n  border-radius: 4px;\n  border-width: 2px;\n  padding: 0 16px;\n  font-size: 16px;\n  font-weight: 700;\n  font-family: Roboto;\n\n  @media screen and (max-width: 700px) {\n    width: 100%;\n  }\n",
            ])),
          f.gray.grayBackground,
          f.primary.redTwo,
          f.gray.white
        ),
        mt = l.d.input(
          te ||
            (te = Object(m.a)([
              "\n  width: 30%;\n  height: 50px;\n  background-color: ",
              ";\n  border-color: ",
              ";\n  color: ",
              ";\n  border-radius: 4px;\n  border-width: 2px;\n  padding: 0 16px;\n  font-size: 16px;\n  font-weight: 700;\n  font-family: Roboto;\n\n  @media screen and (max-width: 700px) {\n    width: 100%;\n  }\n",
            ])),
          f.gray.grayBackground,
          f.primary.redTwo,
          f.gray.white
        ),
        st = l.d.div(
          ne ||
            (ne = Object(m.a)([
              "\n  width: 100%;\n  position: relative;\n  z-index: 2;\n  margin-top: -64px;\n  margin-bottom: 32px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n  padding-right: 32px;\n\n  @media screen and (max-width: 700px) {\n    flex-direction: column;\n    align-items: flex-start;\n    justify-content: center;  \n  }\n",
            ]))
        ),
        ft = l.d.div(
          ae ||
            (ae = Object(m.a)([
              "\n  height: 64px;\n  width: 2px;\n  background-color: ",
              ";\n  margin-left: 16px;\n  margin-right: 16px;\n\n  @media screen and (max-width: 700px) {\n    height: 2px;\n    width: 100%;\n    margin-top: 16px;\n    margin-bottom: 16px;\n  }\n",
            ])),
          f.primary.redTwo
        ),
        ut = l.d.div(
          ie ||
            (ie = Object(m.a)([
              "\n  width: 100%;\n  padding: 2% 5%;\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: flex-start;\n",
            ]))
        ),
        pt = l.d.div(
          re ||
            (re = Object(m.a)([
              "\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n",
            ]))
        ),
        bt = l.d.div(
          oe ||
            (oe = Object(m.a)([
              "\n  transition: all 0.2s ease-in-out;\n  cursor: pointer;\n  \n  &:hover {\n    animation: ",
              " 1s linear infinite;\n  } \n",
            ])),
          Be
        ),
        gt = function () {
          var e = Object(i.useState)("unique"),
            t = Object(se.a)(e, 2),
            n = t[0],
            a = t[1],
            o = Object(i.useState)([]),
            c = Object(se.a)(o, 2),
            l = c[0],
            m = c[1],
            s = Object(i.useState)([]),
            u = Object(se.a)(s, 2),
            p = u[0],
            b = u[1],
            g = Object(i.useState)([]),
            x = Object(se.a)(g, 2),
            h = x[0],
            y = x[1],
            v = Object(i.useState)(0),
            w = Object(se.a)(v, 2),
            k = w[0],
            E = w[1],
            A = Object(i.useState)(0),
            T = Object(se.a)(A, 2),
            O = T[0],
            j = T[1],
            F = Object(i.useState)(0),
            I = Object(se.a)(F, 2),
            C = I[0],
            z = I[1],
            S = Object(i.useState)(!1),
            D = Object(se.a)(S, 2),
            B = D[0],
            P = D[1],
            R = Object(i.useCallback)(function () {
              for (
                var e = "",
                  t =
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
                  n = t.length,
                  a = 0;
                a < 8;
                a++
              )
                e += t.charAt(Math.floor(Math.random() * n));
              return e;
            }, []),
            q = Object(i.useCallback)(
              function () {
                var e = [
                    { id: R(), type: "unique" },
                    { id: R(), type: "unique" },
                  ],
                  t = [
                    { id: R(), type: "traffic" },
                    { id: R(), type: "traffic" },
                  ],
                  n = [
                    { id: R(), secondaryId: R(), type: "quantity" },
                    { id: R(), secondaryId: R(), type: "quantity" },
                  ];
                m(e), b(t), y(n);
              },
              [R]
            ),
            L = Object(i.useCallback)(function (e) {
              a(e);
            }, []),
            N = Object(i.useCallback)(function () {
              window.open("https://guilhermebafica.com.br/", "_blank").focus();
            }, []),
            M = Object(i.useCallback)(
              function (e) {
                0 === e &&
                  l.length <= 2 &&
                  !1 === B &&
                  (Object(d.b)(
                    "Selecione o \xfaltimo campo, para adicionar mais uma op\xe7\xe3o.",
                    {
                      position: "top-right",
                      autoClose: 5e3,
                      hideProgressBar: !1,
                      closeOnClick: !0,
                      pauseOnHover: !0,
                      draggable: !0,
                      progress: void 0,
                      type: "info",
                    }
                  ),
                  P(!0)),
                  e + 1 === l.length &&
                    m(
                      [].concat(Object(me.a)(l), [{ id: R(), type: "unique" }])
                    );
              },
              [R, l, B]
            ),
            V = Object(i.useCallback)(
              function (e) {
                0 === e &&
                  p.length <= 2 &&
                  !1 === B &&
                  (Object(d.b)(
                    "Selecione o \xfaltimo campo, para adicionar mais uma op\xe7\xe3o.",
                    {
                      position: "top-right",
                      autoClose: 5e3,
                      hideProgressBar: !1,
                      closeOnClick: !0,
                      pauseOnHover: !0,
                      draggable: !0,
                      progress: void 0,
                      type: "info",
                    }
                  ),
                  P(!0)),
                  e + 1 === p.length &&
                    b(
                      [].concat(Object(me.a)(p), [{ id: R(), type: "traffic" }])
                    );
              },
              [R, p, B]
            ),
            U = Object(i.useCallback)(
              function (e) {
                0 === e &&
                  h.length <= 2 &&
                  !1 === B &&
                  (Object(d.b)(
                    "Selecione o \xfaltimo campo, para adicionar mais uma op\xe7\xe3o.",
                    {
                      position: "top-right",
                      autoClose: 5e3,
                      hideProgressBar: !1,
                      closeOnClick: !0,
                      pauseOnHover: !0,
                      draggable: !0,
                      progress: void 0,
                      type: "info",
                    }
                  ),
                  P(!0)),
                  e + 1 === h.length &&
                    y(
                      [].concat(Object(me.a)(h), [
                        { id: R(), secondaryId: R(), type: "quantity" },
                      ])
                    );
              },
              [R, h, B]
            ),
            Q = Object(i.useCallback)(
              function () {
                var e = [
                    { id: R(), type: "unique" },
                    { id: R(), type: "unique" },
                  ],
                  t = [
                    { id: R(), type: "traffic" },
                    { id: R(), type: "traffic" },
                  ],
                  n = [
                    { id: R(), secondaryId: R(), type: "quantity" },
                    { id: R(), secondaryId: R(), type: "quantity" },
                  ];
                a("unique"),
                  m(e),
                  b(t),
                  y([]),
                  setTimeout(function () {
                    y(n);
                  }, 500),
                  E(0),
                  j(0),
                  z(0);
              },
              [R]
            ),
            H = Object(i.useCallback)(
              function (e, t) {
                "unique" === t && M(e),
                  "traffic" === t && V(e),
                  "quantity" === t && U(e);
                var n,
                  a = 0,
                  i = 0,
                  r = 0,
                  o = Object(de.a)(l);
                try {
                  for (o.s(); !(n = o.n()).done; ) {
                    var c,
                      d,
                      m,
                      s = n.value,
                      f =
                        null === (c = document.getElementById(s.id)) ||
                        void 0 === c
                          ? void 0
                          : c.value.split("|")[0],
                      u =
                        null === (d = document.getElementById(s.id)) ||
                        void 0 === d
                          ? void 0
                          : d.value.split("|")[1],
                      b =
                        null === (m = document.getElementById(s.id)) ||
                        void 0 === m
                          ? void 0
                          : m.value.split("|")[2];
                    (a += Number(f)), (i += Number(u)), (r += Number(b));
                  }
                } catch (J) {
                  o.e(J);
                } finally {
                  o.f();
                }
                var g,
                  x = Object(de.a)(p);
                try {
                  for (x.s(); !(g = x.n()).done; ) {
                    var y,
                      v,
                      w,
                      k = g.value,
                      A =
                        null === (y = document.getElementById(k.id)) ||
                        void 0 === y
                          ? void 0
                          : y.value.split("|")[0],
                      T =
                        null === (v = document.getElementById(k.id)) ||
                        void 0 === v
                          ? void 0
                          : v.value.split("|")[1],
                      O =
                        null === (w = document.getElementById(k.id)) ||
                        void 0 === w
                          ? void 0
                          : w.value.split("|")[2];
                    (a += Number(A)), (i += Number(T)), (r += Number(O));
                  }
                } catch (J) {
                  x.e(J);
                } finally {
                  x.f();
                }
                var F,
                  I = Object(de.a)(h);
                try {
                  for (I.s(); !(F = I.n()).done; ) {
                    var C,
                      S,
                      D,
                      B,
                      P = F.value,
                      R =
                        null === (C = document.getElementById(P.id)) ||
                        void 0 === C
                          ? void 0
                          : C.value.split("|")[0],
                      q =
                        null === (S = document.getElementById(P.id)) ||
                        void 0 === S
                          ? void 0
                          : S.value.split("|")[1],
                      L =
                        null === (D = document.getElementById(P.id)) ||
                        void 0 === D
                          ? void 0
                          : D.value.split("|")[2],
                      N =
                        null === (B = document.getElementById(P.secondaryId)) ||
                        void 0 === B
                          ? void 0
                          : B.value;
                    (a += Number(R) * Number(N)),
                      (i += Number(q) * Number(N)),
                      (r += Number(L) * Number(N));
                  }
                } catch (J) {
                  I.e(J);
                } finally {
                  I.f();
                }
                var Q = a > 150 ? 150 : a,
                  H = i > 15e4 ? 15e4 : i,
                  G = r > 45e4 ? 45e4 : r;
                !0 === document.querySelector(".reuPrimario").checked &&
                  (Q -= 0.5 * Q),
                  !0 === document.querySelector(".presencaAdvogado").checked &&
                    (Q -= 0.1 * Q),
                  E(Q),
                  j(H),
                  z(G);
              },
              [M, l, V, p, U, h]
            ),
            G = Object(i.useCallback)(function () {
              var e =
                "https://api.whatsapp.com/send?l=pt-BR&phone='5573991115093'&text=".concat(
                  "Ol\xe1 Guilherme, tenho algo pra falar sobre a Calculadora da NexusRP!"
                );
              window.open(e, "_blank").focus();
            }, []);
          return (
            Object(i.useEffect)(
              function () {
                q();
              },
              [q]
            ),
            r.a.createElement(
              r.a.Fragment,
              null,
              r.a.createElement(
                Pe,
                { id: "home" },
                r.a.createElement(
                  Re,
                  null,
                  r.a.createElement(xe, {
                    text: "CALCULADORA PENAL",
                    align: "center",
                    color: f.gray.white,
                    size: 18,
                    weight: "700",
                    fontFamily: "HighSpeed",
                  }),
                  r.a.createElement(
                    rt,
                    null,
                    r.a.createElement(xe, {
                      text: "NEXUS POLICE RP",
                      align: "center",
                      color: f.gray.white,
                      size: 12,
                      weight: "700",
                      fontFamily: "HighSpeed",
                    }),
                    r.a.createElement(
                      ot,
                      null,
                      r.a.createElement(ct, { src: De.a })
                    )
                  )
                ),
                r.a.createElement(
                  qe,
                  null,
                  r.a.createElement(
                    Le,
                    null,
                    r.a.createElement(
                      Ne,
                      null,
                      r.a.createElement(xe, {
                        text: "Preencha com os artigos, para calcular a pena",
                        align: "left",
                        color: f.gray.white,
                        size: 8,
                        weight: "500",
                        letterSpacing: 0.1,
                        fontFamily: "Montroc",
                      })
                    ),
                    r.a.createElement(
                      Me,
                      null,
                      r.a.createElement(ve, {
                        text: "\xdaNICOS",
                        fontSize: 6,
                        onClick: function () {
                          return L("unique");
                        },
                        isActive: "unique" === n,
                      }),
                      r.a.createElement(Ve, null),
                      r.a.createElement(ve, {
                        text: "QUANTITATIVOS",
                        fontSize: 6,
                        onClick: function () {
                          return L("quantity");
                        },
                        isActive: "quantity" === n,
                      }),
                      r.a.createElement(Ve, null),
                      r.a.createElement(ve, {
                        text: "TRANSITO",
                        fontSize: 6,
                        onClick: function () {
                          return L("traffic");
                        },
                        isActive: "traffic" === n,
                      })
                    )
                  ),
                  r.a.createElement(
                    Ge,
                    null,
                    r.a.createElement(
                      Ue,
                      null,
                      r.a.createElement(He, null),
                      r.a.createElement(Qe, { src: ze.a })
                    ),
                    r.a.createElement(
                      Ye,
                      { display: "unique" === n },
                      l.map(function (e, t) {
                        return r.a.createElement(
                          Ze,
                          {
                            id: e.id,
                            key: e.id,
                            onChange: function () {
                              return H(t, e.type);
                            },
                          },
                          r.a.createElement(
                            et,
                            { value: "0 | 0 | 0" },
                            "SELECIONE UM ARTIGO"
                          ),
                          je.map(function (e) {
                            return r.a.createElement(
                              et,
                              {
                                key: e.article,
                                value: ""
                                  .concat(e.time, " | ")
                                  .concat(e.trafficTicket, " | ")
                                  .concat(e.bail),
                              },
                              ""
                                .concat(e.article, " - ")
                                .concat(e.name, " ")
                                .concat(e.note && "-> ".concat(e.note))
                            );
                          })
                        );
                      })
                    ),
                    r.a.createElement(
                      Ye,
                      { display: "quantity" === n },
                      h.map(function (e, t) {
                        return r.a.createElement(
                          lt,
                          { key: e.id },
                          r.a.createElement(
                            dt,
                            { id: e.id, key: e.id },
                            r.a.createElement(
                              et,
                              { value: "0 | 0 | 0" },
                              "SELECIONE UM ARTIGO"
                            ),
                            Ie.map(function (e) {
                              return r.a.createElement(
                                et,
                                {
                                  key: e.article,
                                  value: ""
                                    .concat(e.time, " | ")
                                    .concat(e.trafficTicket, " | ")
                                    .concat(e.bail),
                                },
                                ""
                                  .concat(e.article, " - ")
                                  .concat(e.name, " ")
                                  .concat(e.note && "-> ".concat(e.note))
                              );
                            })
                          ),
                          r.a.createElement(mt, {
                            type: "number",
                            id: e.secondaryId,
                            min: 1,
                            placeholder: "Quantidade",
                            onChange: function () {
                              return H(t, e.type);
                            },
                          })
                        );
                      })
                    ),
                    r.a.createElement(
                      Ye,
                      { display: "traffic" === n },
                      p.map(function (e, t) {
                        return r.a.createElement(
                          Ze,
                          {
                            id: e.id,
                            key: e.id,
                            onChange: function () {
                              return H(t, e.type);
                            },
                          },
                          r.a.createElement(
                            et,
                            { value: "0 | 0 | 0" },
                            "SELECIONE UM ARTIGO"
                          ),
                          Fe.map(function (e) {
                            return r.a.createElement(
                              et,
                              {
                                key: e.article,
                                value: ""
                                  .concat(e.time, " | ")
                                  .concat(e.trafficTicket, " | ")
                                  .concat(e.bail),
                              },
                              ""
                                .concat(e.article, " - ")
                                .concat(e.name, " ")
                                .concat(e.note && "-> ".concat(e.note))
                            );
                          })
                        );
                      })
                    ),
                    r.a.createElement(
                      st,
                      null,
                      r.a.createElement(Oe, {
                        text: "R\xe9u Prim\xe1rio",
                        className: "reuPrimario",
                        onClick: function () {
                          return H(0, "reuPrimario");
                        },
                      }),
                      r.a.createElement(ft, null),
                      r.a.createElement(Oe, {
                        text: "Presen\xe7a Do Advogado",
                        className: "presencaAdvogado",
                        onClick: function () {
                          return H(0, "presencaAdvogado");
                        },
                      })
                    ),
                    r.a.createElement(
                      Xe,
                      null,
                      r.a.createElement(
                        Ke,
                        null,
                        r.a.createElement(
                          _e,
                          null,
                          r.a.createElement(fe.b, {
                            color: f.gray.white,
                            size: 18,
                          }),
                          r.a.createElement(xe, {
                            text: "FIAN\xc7A",
                            align: "left",
                            color: f.gray.white,
                            size: 16,
                            marginLeft: 8,
                            weight: "500",
                            letterSpacing: 0.1,
                            fontFamily: "Montroc",
                          })
                        ),
                        r.a.createElement(xe, {
                          text: "R$ ".concat(
                            new Intl.NumberFormat("pt-BR").format(C)
                          ),
                          align: "right",
                          color: f.gray.white,
                          size: 20,
                          marginTop: 32,
                          weight: "500",
                          letterSpacing: 0.1,
                          fontFamily: "Montroc",
                        })
                      ),
                      r.a.createElement(
                        We,
                        null,
                        r.a.createElement(
                          _e,
                          null,
                          r.a.createElement(ue.a, {
                            color: f.gray.white,
                            size: 18,
                          }),
                          r.a.createElement(xe, {
                            text: "MULTA",
                            align: "left",
                            color: f.gray.white,
                            size: 16,
                            marginLeft: 8,
                            weight: "500",
                            letterSpacing: 0.1,
                            fontFamily: "Montroc",
                          })
                        ),
                        r.a.createElement(xe, {
                          text: "R$ ".concat(
                            new Intl.NumberFormat("pt-BR").format(O)
                          ),
                          align: "right",
                          color: f.gray.white,
                          size: 20,
                          marginTop: 32,
                          weight: "500",
                          letterSpacing: 0.1,
                          fontFamily: "Montroc",
                        })
                      ),
                      r.a.createElement(
                        $e,
                        null,
                        r.a.createElement(
                          _e,
                          null,
                          r.a.createElement(fe.a, {
                            color: f.gray.white,
                            size: 18,
                          }),
                          r.a.createElement(xe, {
                            text: "TEMPO",
                            align: "left",
                            color: f.gray.white,
                            size: 16,
                            marginLeft: 8,
                            weight: "500",
                            letterSpacing: 0.1,
                            fontFamily: "Montroc",
                          })
                        ),
                        r.a.createElement(xe, {
                          text: "".concat(k.toFixed(0), " meses"),
                          align: "right",
                          color: f.gray.white,
                          size: 20,
                          marginTop: 32,
                          weight: "500",
                          letterSpacing: 0.1,
                          fontFamily: "Montroc",
                        })
                      )
                    ),
                    r.a.createElement(
                      Je,
                      null,
                      r.a.createElement(ve, {
                        text: "RESETAR",
                        fontSize: 10,
                        onClick: Q,
                      })
                    )
                  )
                ),
                r.a.createElement(
                  tt,
                  null,
                  r.a.createElement(
                    nt,
                    null,
                    r.a.createElement(
                      at,
                      { onClick: N },
                      r.a.createElement(
                        it,
                        null,
                        "Feito por Guilherme Bafica",
                        r.a.createElement(
                          "span",
                          null,
                          " (Francesco Virgolini ou Jeremias)"
                        )
                      )
                    )
                  )
                ),
                r.a.createElement(
                  ut,
                  null,
                  r.a.createElement(xe, {
                    text: "Projeto desenvolvido para a cidade Nexus RP",
                    align: "left",
                    color: f.gray.white,
                    size: 10,
                    weight: "500",
                    fontFamily: "Dosis",
                    marginBottom: 4,
                  }),
                  r.a.createElement(
                    pt,
                    null,
                    r.a.createElement(xe, {
                      text: "Qualquer problema, entre em contato (basta clicar no nome) => ",
                      align: "left",
                      color: f.gray.white,
                      size: 8,
                      weight: "500",
                      fontFamily: "Dosis",
                    }),
                    r.a.createElement(
                      bt,
                      { onClick: G },
                      r.a.createElement(xe, {
                        text: "Guilherme Bafica",
                        align: "left",
                        color: f.gray.white,
                        size: 8,
                        marginLeft: 4,
                        textDecoration: "underline",
                        weight: "500",
                        fontFamily: "Dosis",
                      })
                    )
                  )
                )
              )
            )
          );
        },
        xt = l.d.div(
          ce ||
            (ce = Object(m.a)([
              "\n  background: ",
              ";\n  height: 8px;\n  position: sticky;\n  bottom: 0;\n  width: 100%;\n  z-index: 10;\n",
            ])),
          f.primary.redTwo
        ),
        ht = function () {
          return r.a.createElement(
            r.a.Fragment,
            null,
            r.a.createElement(xt, null)
          );
        },
        yt = function () {
          return (
            Object(i.useEffect)(function () {
              console.log(" "),
                console.log(" "),
                console.log(
                  "%c Made with \u2764\ufe0f by Guilherme Bafica (Francesco Virgolini ou Jeremias) e Lobo Branco(Biuzera).",
                  "color: #01bf71; background: #010606; border-radius: 4px; padding: 10px; font-size: 12px; font-weight: bold"
                ),
                console.log(" "),
                console.log(" ");
            }, []),
            r.a.createElement(
              i.Fragment,
              null,
              r.a.createElement(gt, null),
              r.a.createElement(ht, null)
            )
          );
        },
        vt = function () {
          return r.a.createElement(
            p.a,
            null,
            r.a.createElement(le, null),
            r.a.createElement(
              b.c,
              null,
              r.a.createElement(b.a, { exact: !0, path: "/", component: yt })
            )
          );
        },
        wt =
          (n(46),
          function () {
            return r.a.createElement(
              l.a,
              { theme: s },
              r.a.createElement(d.a, {
                position: "top-right",
                autoClose: 5e3,
                hideProgressBar: !1,
                newestOnTop: !1,
                closeOnClick: !0,
                rtl: !1,
                pauseOnFocusLoss: !0,
                draggable: !0,
              }),
              r.a.createElement(vt, null),
              r.a.createElement(u, null)
            );
          });
      c.a.render(
        r.a.createElement(r.a.StrictMode, null, r.a.createElement(wt, null)),
        document.getElementById("root")
      );
    },
  },
  [[34, 1, 2]],
]);
//# sourceMappingURL=main.ad93aa80.chunk.js.map
